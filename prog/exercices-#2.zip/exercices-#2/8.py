x = float(input("X: "))
y = float(input("Y: "))

expressao = ((x + 3) ** 2 + 5) / (x * y)

print(expressao)