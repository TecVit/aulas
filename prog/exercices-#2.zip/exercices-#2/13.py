x = float(input("X: "))
y = float(input("Y: "))

pi = 3.1415
resultado = (((x + 2) ** 2 + pi) / (x * y)) * (5 / pi)

print(f"{resultado:.4f}")