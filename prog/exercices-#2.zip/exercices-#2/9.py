base = float(input("Base: "))
altura = float(input("Altura: "))

area = (base * altura) / 2

print(f"A area do triângulo é {area}")