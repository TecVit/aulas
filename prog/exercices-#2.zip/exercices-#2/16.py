n = int(input())

centena = n // 100
dezena = n // 100
unidade = n // 1

print(centena)
print(dezena)
print(unidade)