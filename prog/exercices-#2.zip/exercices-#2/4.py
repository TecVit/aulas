salario = float(input("Salário: R$"))
porcent_10 = salario * (10 / 100)

final = salario + porcent_10

print(f"Salário Final: R${final:.2f}")