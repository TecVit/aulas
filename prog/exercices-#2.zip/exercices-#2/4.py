salario = float(input("Salário: "))
porcent_10 = salario * (10 / 100)

final = salario + porcent_10

print(final)