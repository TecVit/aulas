x = int(input("X: "))
y = int(input("Y: "))
z = int(input("Z: "))
w = int(input("W: "))

total_letras = x * y * z * w

print(total_letras)