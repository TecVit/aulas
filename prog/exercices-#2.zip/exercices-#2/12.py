raio = float(input("Raio: "))
pi = 3.1415

area =  pi * raio ** 2

print(area)