a = int(input("A: "))
b = int(input("B: "))

soma = a + b
subtracao = a - b
multiplicacao = a * b
divisao = a / b

print(f"Soma: {soma}")
print(f"Subtração: {subtracao}")
print(f"Multiplicação: {multiplicacao}")
print(f"Divisão: {divisao}")