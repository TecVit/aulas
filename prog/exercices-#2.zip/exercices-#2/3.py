n = float(input())

p20 = n * (20/100)
p5 = n * (5/100)
p04 = n * (0.5/100)

print(p20)
print(p5)
print(p04)