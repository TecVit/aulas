horas_normais = 40
valor_normal = 20

valor_extra = 30
horas_extras = 10

salario_base = (horas_normais * valor_normal) + (horas_extras * valor_extra)
bonus = salario_base * (10 / 100)

salario_total = salario_base + bonus

print(salario_total)