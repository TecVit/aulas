horas = 160 # 40 Horas Semanais
valor = 25 # 25 Reais

salario_base = horas * valor # 4.000 Reais
gratificacao = salario_base * (5 / 100) # 200 Reais

salario_total = salario_base + gratificacao # 4.200 Reais

inss = salario_total * (8 / 100) # 420 - 84

salario_liquido = salario_total - inss

print(salario_liquido)