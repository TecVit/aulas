c = int(input("Graus Celsius: "))
f = c * (9/5) + 32

print(f"{c} Graus Celsius em Fahrenheit é {f}")