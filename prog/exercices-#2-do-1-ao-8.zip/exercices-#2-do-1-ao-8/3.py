n = float(input())

p20 = n * (20/100)
p5 = n * (5/100)
p05 = n * (0.5/100)

print(f"20% de {n} é {p20}")
print(f"5% de {n} é {p5}")
print(f"0.5% de {n} é {p05}")