x = int(input("X: "))
y = int(input("Y: "))
z = int(input("Z: "))
w = int(input("W: "))

total_letras = x * y * z * w

print(f"O Total de letras é de {total_letras}")