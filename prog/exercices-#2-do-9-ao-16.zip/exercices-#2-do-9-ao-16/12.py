raio = float(input("Raio: "))
pi = 3.1415

area =  pi * raio ** 2

print(f"A área do círculo é {area:.2f}")