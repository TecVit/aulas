n1 = int(input())
n2 = int(input())

m = n1 * n2
d = n1 / n2

print(f"A multiplicação ({n1} x {n2}) é: {m}")
print(f"A divisão ({n1} / {n2}) é: {d}")
