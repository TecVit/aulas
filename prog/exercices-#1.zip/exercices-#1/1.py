n1 = int(input())
n2 = int(input())

sum = n1 + n2

print(f"O Resultado da expressão {n1} + {n2} = {sum}")
