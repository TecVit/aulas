a = int(input())
b = int(input())
c = int(input())

result = a + b * c

print(f"O Resultado da expressão {a} + {b} * {c} = {result}")
