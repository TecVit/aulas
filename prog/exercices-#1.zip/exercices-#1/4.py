x = int(input())

p5 = x * (5/100)
p10 = x * (10/100)
p50 = x * (50/100)

print(f"5% de {x} é {p5}")
print(f"10% de {x} é {p10}")
print(f"50% de {x} é {p50}")