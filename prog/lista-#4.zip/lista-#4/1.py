valor = int(input("Digite um valor: "))
porcentagem = int(input("Digite uma porcentagem (0 a 100): "))

resultado = valor * (porcentagem / 100)

print(f"{porcentagem}% de {valor} é igual a: {resultado}")