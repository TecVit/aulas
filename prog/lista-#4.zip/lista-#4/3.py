a = int(input("Valor de A: "))
b = int(input("Valor de B: "))

quociente = a // b
resto = a % b

print(f"O queciente da divisão de {a} sobre {b} é {quociente}")
print(f"O resto da divisão de {a} sobre {b} é {resto}")