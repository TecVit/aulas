x = 45

porcent_5 = 45 * (5 / 100)
print(porcent_5)

porcent_10 = 45 * (10 / 100)
print(porcent_10)

porcent_50 = 45 * (50 / 100)
print(porcent_50)