a = 5
b = 2
c = 3
result = a + b * c

print(result)