number_one = 5
number_two = 9
sum = number_one + number_two

print(sum)