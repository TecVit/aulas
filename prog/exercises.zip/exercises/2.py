number_one = 5
number_two = 10

multiplication = number_one * number_two
division = number_one / number_two

print(multiplication)
print(division)