n = int(input("Digite um número: "))

if n % 2 == 0:
    print("O número é divisivel por 2")
if n % 3 == 0:
    print("O número é divisivel por 3")
if n % 5 == 0:
    print("O número é divisivel por 5")
if n % 7 == 0:
    print("O número é divisivel por 7")